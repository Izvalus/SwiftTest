import UIKit

var dic = ["key": "value"]
dic["key"]
dic["mam"] = "Helena"
dic
var array = ["mother", "dad"]
array[0]

//

struct Table {
    
    var multi: Int
    subscript(index: Int) -> Int {
            return multi * index
    }
}

var tableResult = Table(multi: 3)
tableResult[10]

//

struct Man {
    var man1 = "Hello"
    var man2 = "I'm good"
    var man3 = "Hi"
    
    subscript(index: Int) -> String? {
        get {
            switch index {
            case 0: return man1
            case 1: return man2
            case 2: return man3
            default: return ""
            }
        } set {
            let value = newValue ?? ""
            switch index {
            case 0: return man1 = value
            case 1: return man2 = value
            case 2: return man3 = value
            default: break
            }
        }
    }
}

var say = Man()
say[0] = "Hi, Jack"
say.man1

//

class Family {
    var mother = ""
    var dad = ""
    var child = ""
    
    subscript(index: Int) -> String? {
        get {
            switch index {
            case 0: return mother
            case 1: return dad
            case 2: return child
            default: return "No family"
            }
        } set {
            let valueNil = newValue ?? ""
            switch index {
            case 0: return mother = valueNil
            case 1: return dad = valueNil
            case 2: return child = valueNil
            default: break
            }
        }
    }
}
var family = Family()
family[0] = "Sandra"
family[1] = "John"
family[2] = "Minijack"
family.child

//

struct Calculations {
    
    let multiplication = 100
    let share = 2
    subscript(index: Int) -> Int {
        return index * multiplication / share
    }
}
var calculations = Calculations()
calculations[4]

//

struct Color {
    var black = "Black"
    var white = "White"
    subscript(index: Bool) -> String {
        if index == true {
            let bl = "The figure is \(black)"
            return bl
        } else {
            let wh = "The figure is \(white)"
            return wh
        }
    }
}
var color = Color()
color[true]
color[false]

//

class Human {
    
    var name = "Tony"
    var age = 25
    var gender = "male"
    
}
class Profession: Human {
    func test(occepation: Bool) -> String {
        if occepation == true {
            let occepations = "Ingineer"
            print(occepations)
            return occepations
        } else {
            let occepations = "Humanities"
            print(occepations)
            return occepations
        }
    }
}
var human = Human()
var professionHuman = Profession()
professionHuman.test(occepation: true)
professionHuman.test(occepation: false)

//

let dictionary = [String: Any]()
