// Food basket

protocol Food {
    var name: String { get }
    func taste()
}

protocol Storable: Food {
    var expired: Bool { get }
    var daysToExpire: Int { get }
}

struct Pizza: Food {
    var name: String
    
    func taste() {
        print("what a delicious pizza")
    }
}

struct Milk: Storable {
    var daysToExpire: Int
    
    var expired: Bool
    
    var name: String
    
    func taste() {
        print("like in the village")
    }
}

struct Bread: Food {
    var name: String
    
    func taste() {
        print("Fresh from the oven, still warm!")
    }
}

struct Chocolate: Food {
    var name: String
    
    func taste() {
        print("My favorite, with nuts")
    }
}

struct Kefir: Storable {
    var expired: Bool
    
    var daysToExpire: Int
    
    var name: String
    
    func taste() {
        print("Great kefir!")
    }
    
    
}

let pizza = Pizza(name: "Margarite")
let milk = Milk(daysToExpire: 9, expired: false, name: "Vkusnoteevo")
let bread = Bread(name: "Borodinskiy")
let chocolate = Chocolate(name: "Milka")
let kefir = Kefir(expired: false, daysToExpire: 7, name: "Ivan Poddubniy")


func storage(array: [Food]) -> [Storable]{
    
    var fridge: [Storable] = []
    
    for i in array {
        if let food = i as? Storable {
            fridge.append(food)
            }
        }
    return fridge
}

var bag: [Food] = [pizza, milk, bread, chocolate, kefir]

let fridge = storage(array: bag).sorted(by: { (a, b) -> Bool in
    a.daysToExpire < b.daysToExpire
})

func consoleOutput() {
    print("--------Все продукты----------")
    
    for value in bag {
      
        print("\(value.name): "); value.taste()
    
    }
    
    print("---------- Продукты, которые могут пропасть ---------")
    for i in fridge {
        
        print("\(i.name):")
        
        if i.expired == false {
            print("Еще не пропало, нужно отправить в холодильник")
        } else {
            print("Пропало, пора выбросить")
        }
        
        if i.daysToExpire <= 7 {
            print("\(i.daysToExpire) дней до того, как пропадёт, нужно съедать в первую очередь")
        } else {
            print("\(i.daysToExpire) дней до того, как пропадёт, время есть ;)")
        }
    }
    
}

consoleOutput()

