
// Training


class Human {

    var father: Man?
    var mother: Women?
    var brothers: [Man]?
    var sisters: [Women]?
    var animals: [Animal]?
    

}

class Women {
    func direction() -> String {
        return "give direction"
    }
}

class Man {
    
    func sofa() -> String {
        return "move the sofa"
    }
}

class Animal {
    
    func sound() -> String {
        return ""
    }
}

class Cat: Animal {
    
    override func sound() -> String {
        return "Meow!"
    }
}

class Dog: Animal {
    
    override func sound() -> String {
        return "Woof!"
    }
}

class Crow: Animal {
    
    override func sound() -> String {
        return "Kar!"
    }
}


let family: [Any] = (0 ..< 30).map { index in
    if index % 2 == 0 {
        return Man()
    } else {
        return Women()
    }
}

var countMan = 0
var countWoman = 0



for i in family {
    if let man = i as? Man {
        man.sofa()
        countMan += 1
    } else if let woman = i as? Women {
        woman.direction()
        countWoman += 1
    }
}

countWoman
countMan

//

let arrayHuman: [Human] = (0 ..< 30).map { index in
    let human = Human()
    if index % 3 == 0 {
        let arrayRand: [Animal] = [Dog(), Cat(), Crow()]
        human.animals = [arrayRand.randomElement()] as! [Animal]
    }
    return human
}


var animalsArray  = [Animal]()
var countAnimal = 0


for i in arrayHuman {
    if i.animals != nil {
        animalsArray.append(contentsOf: i.animals!)
        countAnimal += 1
    }
}

for i in animalsArray {
    print(i.sound())
}
animalsArray

countAnimal




