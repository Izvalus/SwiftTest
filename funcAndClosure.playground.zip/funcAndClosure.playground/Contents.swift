//----------------------------------Training, function and closure--------------------------------------------------

func testMethod(closure:()->Void) {
    closure()
}
testMethod(closure: { print( "hello world") })

//

func task1(closure: () -> Void) {
    
    for i in 1...10 {
        print(i)
    }
    
}

task1(closure: { })
task1(closure: { })

//

func task2(array: [Int]) {
    print(array.sorted())
}
var task2Array = [1, 3, 2, 4, 6, 2, 42, 123, 12, 32, 21, 23]
task2(array: task2Array)

let a = task2Array.sorted(){$0 > $1}
let b = task2Array.sorted(){$0 < $1}
print(a)
print(b)

//

func cleanFunc(value:Int) -> Int { return value + 1}

var value: Int = 0
func metod() -> Int { return value + 1 }


var ghil = "Hello world! "

func cleanStr(value: String) -> Character? {
    
    return value.first
   
}
print(cleanStr(value: ghil)!)

//Например, принять массив чисел, а вернуть массив строк

func arra(arraInt: [Int]) -> [String] {
    var str = [String]()
    for i in arraInt {
        str.append(String(i))
    }
    
    return str
}
var see = [1, 3, 2, 4, 6, 7, 3]
arra(arraInt: see)
print(arra(arraInt: see))

//Метод map у массива

func testMap(_ x: Int) -> String {
    return String(x)
}
let testMap1 = see.map(testMap)
let testMap2 = see.map {"\($0)"}.reduce("") { $0 + $1 }
print(testMap2)


//Найти в массиве все нечетные, метод filter


let arrayUneven = [1, 3, 5, 2, 2, 3, 4, 6, 8, 43, 23]
print(arrayUneven.filter {$0 % 2 == 1})
print(arrayUneven.filter {$0 % 2 == 0})


//

var parrayEven = [1, 3, 2, 5, 6, 8, 9, 4, 2, 4, 6, 8, 11]
let parrayEvenTest = parrayEven.compactMap { $0 % 2 == 1 }.map {"\($0)"}
print(parrayEvenTest)






