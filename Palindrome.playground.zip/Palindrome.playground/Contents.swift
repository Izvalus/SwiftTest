

func palindrome(element: String) {
    
    var elementArrayOne = [String]()
    
    for i in element {
        elementArrayOne.append(String(i))
    }
    elementArrayOne
    var elementArrayTwo = elementArrayOne
    elementArrayTwo.reverse()
    
    if elementArrayOne == elementArrayTwo {
        print("true")
    } else {
        print("false")
    }
}

palindrome(element: "teset")


