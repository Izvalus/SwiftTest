
// Extensions


extension Int {
    
    var isEven: Bool {
        return self % 2 == 0
    }
    
    var isOdd: Bool {
        return !isEven
    }
    
    enum EvenOrOdd {
        case Even
        case Odd
    }
    
    var evenOrOdd: EvenOrOdd {
        return isEven ? .Even : .Odd
    }
    
    func pow(_ value: Int) -> Int {
        
        var temp = self
        for _ in 1 ..< value {
            temp *= self
        }
        return temp
    }
    
    mutating func powTo(value: Int) {
        self = pow(value)
    }
    
    var binaryString: String {
        
        var result = ""
        for i in 0..<8 {
            result = String(self & (1 << i) > 0) + result
        }
        
        return result
    }
    
    
    
    
}

extension String {
    init(_ value: Bool) {
        self.init(value ? 1 : 0)
    }
}

extension Int.EvenOrOdd {
    
    var string: String {
    
    switch self {
    case .Even: return "even"
    case .Odd: return "odd"
        }
    }
}
var a = 5

if a % 2 != 0 {
    print("a")
}

if a.isOdd {
    print("a")
}

a.evenOrOdd.string

a.pow(3)
a
a.binaryString
a.powTo(value: 3)
a
a.binaryString

//

extension Int {
    var isNegative: Bool {
        return self % 10 == 0
    }
    
    var isPositive: Bool {
        return !isNegative
    }
    var symbols: Int {
        let test = String(self)
        return test.count
    }
}


var test = 1011041
test.isNegative
test.isPositive
var test1 = "Hello"
test.symbols
