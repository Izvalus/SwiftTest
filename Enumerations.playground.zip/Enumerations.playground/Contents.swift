//-------------Enumerations----------------


enum Action {
    case Walk(meters: Int)
    case Run(meters: Int, speed: Double)
    case Stop
    case Turn(direction: Direction)
    
    enum Direction: String {
        case Left = "Left !"
        case Right = "Right !"
    }
}

var action = Action.Run(meters: 20, speed: 15.0)

//action = .Stop
//action = .Walk(meters: 15)

//action = .Turn(direction: .Left)

var direction = Action.Direction(rawValue: "Right !")!

action = .Turn(direction: direction)

switch action {
case .Stop: print("Stop")
//case .Walk (let meters): print("walk \(meters) meters")
case .Walk (let meters) where meters < 100:
    print("short walk")
case .Walk (let meters):
    print("long walk")
case .Run (let m, let s):
    print("run \(m) meters with speed \(s)")
case .Turn(let dir) where dir == .Left:
    print("Turn Left")
case .Turn(let dir) where dir == .Right:
    print("Turn Right")
    
default: break
}

print(Action.Direction.Left.rawValue)

//

enum TravelClass {
    case First, Buseness, Economy
}

let travel = TravelClass.First

//

enum Medal {
    case gold
    case silver
    case bronze
}

let medal = Medal.gold

switch medal {
case .gold:
    print("Medal gold")
case .silver:
    print("Medal silver")
case .bronze:
    print("Medal bronze")
}

//

enum DayWeek {
    case mondey
    case tuesday
    case wednesday
    case thersday
    enum friday {
        case day
        case night
    }
    case saturday
    case sunday
}

var friday = DayWeek.friday.day

//

enum operation {
    case double(Double)
    case integer(Int)
    case float(Float)
    case string(String)
}

var dictionary: Dictionary<String, operation> = [
    "Double": operation.double(22.4),
    "Integer": operation.integer(10),
    "Float": operation.float(44.1),
    "String": operation.string("String")
]

let pr = dictionary["String"]
print(pr!)

//

enum Animals {
    case cat
    case dog
    case gorilla
    case wolf
}

var animals = Animals.dog
animals = .wolf

//

enum Planets {
    case mercury
    case earth
    case venus
    case mars
}

let planets = Planets.mercury

//

enum profile {
    case name
    case surname
    case age
    case profession
}

let prof = profile.profession

switch prof {
case .name:
    print("Name is Ignat")
case .surname:
    print("Surname is Abakhov")
case .age:
    print("15 years")
case .profession:
    print("HZ")
}

//

enum rainbow {
    case red
    case orange
    case yellow
    case green
    case blue
    case indigo
    case violet
}

func items(item: rainbow) {
    let it = ["tomatos", "orange", "lemon", "avocado", "sky", "sea", "eggplant"]
    switch item {
    case .red:
        print("\(it[0]) red")
    case .orange:
        print("\(it[1]) orange")
    case .yellow:
        print("\(it[2]) yellow")
    case .green:
        print("\(it[3]) green")
    case .blue:
        print("\(it[4]) blue")
    case .indigo:
        print("\(it[5]) indigo")
    case .violet:
        print("\(it[6]) violet")
    }
}

items(item: rainbow.red)
items(item: rainbow.orange)
items(item: rainbow.yellow)
items(item: rainbow.green)
items(item: rainbow.blue)
items(item: rainbow.indigo)
items(item: rainbow.violet)

//

var rating = [2, 4, 5, 3, 4, 5, 2, 3, 4]

func averagePoint(rating: [Int]) -> Float {
    let sumRating = Float(rating.reduce(0, {x, y in x + y}))
    let countRating = Float(rating.count)
    let averageMark = Float(sumRating / countRating)
    print(averageMark)
    return averageMark
}
averagePoint(rating: [2, 3, 4, 5, 2, 5, 2, 3])
let test = [5, 5, 5, 5, 4, 5, 5, 4]
averagePoint(rating: test)

//

enum Garage {
    case Lada
    case Suzuki
    case Mercedes
    case BMW
    case Audi
    case Volvo
}

func garageCar(auto: Garage) {
    switch auto {
    case .Lada:
        print("This car brand is in the garage.")
    case .Suzuki:
        print("This car brand is in the garage.")
    case .Mercedes:
        print("This car brand is in the courtyard, cars of this brand do not have their own garage.")
    case .BMW:
        print("This car brand is in the courtyard, cars of this brand do not have their own garage.")
    case .Audi:
        print("This car brand is in the courtyard, cars of this brand do not have their own garage.")
    case .Volvo:
        print("This car brand is in the garage.")
    }
    
}

garageCar(auto: .Audi)
garageCar(auto: .Lada)







