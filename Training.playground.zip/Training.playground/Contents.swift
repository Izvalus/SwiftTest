

class Planets {
   static var count = 0
}


class SupremeRobot: Planets {
    var name: String
    var creature: Int
    
    func say() -> String {
       return "Hello, i'm \(name)"
    }
    
    
    
    init(name: String, creature: Int) {
        self.name = name
        self.creature = creature
        Planets.count += 1
    }
    
    

    
}

class Robot: SupremeRobot {
    
    override func say() -> String {
        return super.say() + "we need new robots"
    }
}

class Robot1: SupremeRobot {
    
    override func say() -> String {
        return super.say() + "we need details"
    }
}

class Robot2: SupremeRobot {
    
    override func say() -> String {
        return super.say() + "we need new robots and parts"
    }
}

var planets = Planets()
var supremeRobot = SupremeRobot(name: "King", creature: 0)
var robot = Robot(name: "C-100", creature: 3)
var robot1 = Robot1(name: "C-101", creature: 5)
var robot2 = Robot2(name: "C-102", creature: 7)

supremeRobot.say()
robot.say()
robot1.say()
robot2.say()
Planets.count
