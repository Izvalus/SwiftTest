// Property

struct Observer {
    
    var name: String {
        
        willSet {
            print("willSet" + " = " + newValue.uppercased())
        }
        
        didSet {
            print("didSet" + " = " + oldValue)
        }
    }
}

var obser = Observer(name: "Jack")

obser.name //getter
obser.name = "Ivan" //setter

print(obser.name)

//

struct ComputerProperty {
    
    var firstName: String
    var lastName: String
    
    var fullName: String {
        get {
            return firstName + " " + lastName
        }
        
        set {
            print("setter is Work" + " " + newValue)
        }
    }
}
var compProp = ComputerProperty(firstName: "John", lastName: "Smith")

compProp.fullName = "What ?"
compProp.fullName
compProp.firstName = "Jack"

print(compProp.fullName)

//
let MaxLengt = 15

struct MyStruct {
    static var count = 0
    var name = String() {
        didSet {
            if name.characters.count > MaxLengt {
                name = oldValue
            }
        }
    }
    init(name: String) {
        
        self.name = name
        MyStruct.count += 1
    }
}

var struct1 = MyStruct(name: "Ivan")
MyStruct.count
struct1.name = "Jack"
print(struct1.name)
var struct2 = MyStruct(name: "Max")
var struct3 = MyStruct(name: "Nikolay")
var struct4 = MyStruct(name: "Ignat")
print(MyStruct.count)

//

class AgeMan {
    
    static var maxAge = 8
    
    lazy var say = "I'm good"
    
    var name = String() {
        didSet {
            if name.characters.count > MaxLengt {
                name = oldValue
            }
        }
    }
    var age = Int() {
        didSet {
            if age > AgeMan.maxAge {
                age = oldValue
                print("6 - 8 years")
            }
        }
    }
    
}

var ageClass = AgeMan()
ageClass.name = "Ivan"
ageClass.age = 15
ageClass.say

//

class IOS {
    var dateOfBirth = String()
    var skills = String()
}

//

struct Resume {
    var surname = String()
    var name = String()
    var post = String()
    var experience = String()
    var data = String()
}
var resume = Resume(surname: "Smith", name: "Jack", post: "IOS", experience: "3 years", data: "9991234567-8")
resume.surname
