// Inheritance

class People {
    
    var name = "John"
    var lastName = "Smith"
    var fullName: String {
        return name + " " + lastName
    }
    func printMethod() -> String {
        return "Your name - "
    }
}

class Man: People {
    
    override func printMethod() -> String {
        return super.printMethod() + "John"
    }
    
}

let people = People()
people.name
people.name
let man = Man()
man.name
man.printMethod()

// Encapsulation

class Boys {
    public var firstName = "Jack"
    private var lastName = "Mishel"
    final func printHi() {
        print("Hi")
    }
}

class Girls: Boys {
   
}
let boys = Boys()


let girls = Girls()
girls.printHi()

// Polymorphism

class General {
    func methodHi() {
        print("Hello, I'm General !")
    }
}

class People1: General {
    override func methodHi() {
        print("Hi, I'm Pople1 !")
    }
}

class People2: General {
    override func methodHi() {
        print("Hi, I'm People2 !")
    }
}

let general = General()
let people1 = People1()
let people2 = People2()

var array = [general, people1, people2]

for obj in array {
    obj.methodHi()
}

//

class Humans {
    var name = ""
    var height = Int()
    var weight = Int()
    var gender = Bool()
    init(name: String, height: Int, weight: Int, gender: Bool) {
        self.height = height
        self.weight = weight
        self.name = name
        self.gender = gender
    }
    func say() {
        if gender == true {
            print("My name is \(name), my height is \(height), my weight is \(weight), i'm a man")
        } else {
            print("My name is \(name), my height is \(height), my weight is \(weight),i am a woman")
        }
    }
}

class Cook: Humans {
    override func say() {
        super.say()
        print("i'm cook")
    }
}

class Manager: Humans {
    override func say() {
        super.say()
        print("i'm manager")
    }
}

class Fighter: Humans {
    override func say() {
        super.say()
        print("i'm fighter")
    }
}

var cook = Cook(name: "Jack", height: 185, weight: 81, gender: true)

var manager = Manager(name: "John", height: 179, weight: 75, gender: true)

var fighter = Fighter(name: "Sandra", height: 170, weight: 54, gender: false)

var array1 = [cook, manager, fighter]
for i in array1 {
    i.say()
}









