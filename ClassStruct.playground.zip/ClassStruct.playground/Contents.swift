//class

class PerensClass {
    var array = [String]()
    var name = ""
    var age = 20
    
    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }
}

class Son: PerensClass {
    
    func method(name: String) {
        print("Hello, \(name)")
    }
}

var sonClass = Son(name: "Iron", age: 30)

sonClass.name
sonClass.method(name: "Jack")

sonClass.name = "Bob"
sonClass.age = 25

//struct

struct NameStruct {
    var name: String
    var age: Int
}

var str = NameStruct(name: "Max", age: 20)

str.name = "John"

//

class Parent {
    var name = ""
    var age = Int()
    
}

class Daughter: Parent {

}

class Grandson: Parent {
    
}

//

class House {
    var width = Int()
    var height = Int()
  
    init(width: Int, height: Int) {
        self.width = width
        self.height = height
    }
}

class OneLevel: House {
 
    func destroy(widht: Int, height: Int) {
        if widht > 100 || height > 50 {
            print("Destroy")
        } else {
            let compos = width * height
            print(compos)
        }
      
    }
    
}

var composition = OneLevel(width: 10, height: 20)
composition.width = 4
composition.height = 11
composition.destroy(widht: 4, height: 11)
composition.destroy(widht: 100, height: 55)

//

class Sorted {
    func sort(array: [String]) {
        let plok = array.sorted()
        print(plok)
    }
}
let test = ["Jack", "John", "Alex", "Ignat", "Ben"]
var qwerty = Sorted()
qwerty.sort(array: test)

