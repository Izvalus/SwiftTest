class Human {
    
    var firstname = ""
    var lastname = ""
    var fullname: String {
        return firstname + " " + lastname
    }
    func sayHello() -> String {
        return "Hello"
    }
}

class Kid: Human {
    override func sayHello() -> String {
        return "Agu"
    }
}

class Boss: Human {
    override func sayHello() -> String {
        return super.sayHello() + ", I'm \(fullname)"
    }
}

let human = Human()
human.firstname = "Johnatan"
human.lastname = "Smith"
print(human.sayHello())
let kid = Kid()
kid.firstname = "Jack"
kid.lastname = "Dreyk"
print(kid.sayHello())
let boss = Boss()
boss.firstname = "Natan"
boss.lastname = "Dreyk"
print(boss.sayHello())

var array = [human, kid, boss]

for i in array {
    print(i.sayHello())
}

//

class Artist {
    var firstname = ""
    var lastname = ""
    var fullname: String {
        return firstname + " " + lastname
    }
    func performance() -> String {
        return "My name is \(fullname)"
    }
}

class Actor: Artist {
    override func performance() -> String {
        return super.performance() + ", I play a role"
    }
}

class Clown: Artist {
    override func performance() -> String {
        return super.performance() + ", I'm kidding"
    }
}

class Singer: Artist {
    override func performance() -> String {
        return super.performance() + ", I sing"
    }
}

class Painter: Artist {
    override func performance() -> String {
        return "My name is Jack London, I'm drawing"
    }
}

let artist = Artist()
artist.firstname = ""
artist.lastname = "Stark"
let actor = Actor()
actor.firstname = "Tony"
actor.lastname = "Stark"
let clown = Clown()
clown.firstname = "Joe"
clown.lastname = "Jocker"
let singer = Singer()
singer.firstname = "Justin"
singer.lastname = "Timberlacke"
let painter = Painter()
painter.firstname = "Johnny"
painter.lastname = "Smith"

var arrayArtist = [actor, clown, singer, painter]

for i in arrayArtist {
    print(i.performance())
}

//

class Transportation {
    var speed = Int()
    var capacity = Int()
    var costOfOneTransportation = Int()
    init(speed: Int, capacity: Int, costOfOneTransportation: Int) {
        self.speed = speed
        self.capacity = capacity
        self.costOfOneTransportation = costOfOneTransportation
    }
}

class Airplane: Transportation {
    
}

class Ship: Transportation {
    
}

class Helicopter: Transportation{
    
}

class Car: Transportation {
    
}

class Train: Transportation {
    
}

let airplane = Airplane(speed: 500, capacity: 100, costOfOneTransportation: 9000)
let ship = Ship(speed: 60, capacity: 150, costOfOneTransportation: 7000)
let helicopter = Helicopter(speed: 250, capacity: 4, costOfOneTransportation: 14000)
let car = Car(speed: 110, capacity: 2, costOfOneTransportation: 1000)
let train = Train(speed: 90, capacity: 200, costOfOneTransportation: 4500)
